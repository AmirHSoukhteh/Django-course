List_1 = [1,2,3,4,5]
List_2 = [4,5,6,7,8]

List_1.extend(List_2)
print(List_1)

distinc = list(set(List_1))
print(distinc)

print(distinc[:3])