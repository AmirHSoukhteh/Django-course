n = int(input())

def sum_n(number):
    return sum(range(number+1))

print(sum_n(n))